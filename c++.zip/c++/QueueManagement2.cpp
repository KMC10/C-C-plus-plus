#include <iostream>
using namespace std; 

class Queue { 
	int size; 
	int* queue; 
	
	public:
	Queue() {
		size = 0;
		queue = new int[100];
	}
    //remove at the front
	void remove() { 
		if (size == 0) { //check if queue is empty
			cout << "Queue is empty"<<endl; 
			return; 
		} 
        //if not empty we loop thru array and remove first element
		else { 
			for (int i = 0; i < size - 1; i++) { 
				queue[i] = queue[i + 1]; 
			} 
			size--; 
		} 
	} 
    //print queue
	void print() { 
		if (size == 0) { 
			cout << "Queue is empty"<<endl; 
			return; 
		} 
		for (int i = 0; i < size; i++) { 
			cout<<queue[i]<<" <- ";
		} 
		cout <<endl;
	}
	void add(int x) {
        if (size >= 100) {
            cout << "Queue is full" << endl;
            return;
        }
        queue[size] = x;
        size++;
    }
    friend Queue operator + (const Queue &q1, const Queue &q2)
{
    int i = 0;

    Queue q;
 
    q.size = q1.size + q2.size;

    for(i = 0; i<q1.size; i++)
    {
        q.queue[i]=q1.queue[i];
    }      
    for(int k=0; k<q2.size; k++)
    {
        q.queue[i]=q2.queue[k];

        i++;
    }    
    return q;
}
	
}; 

int main() { 
	Queue q1; 
	q1.add(42); q1.add(2); q1.add(8);  q1.add(1);
	Queue q2;
	q2.add(3); q2.add(66); q2.add(128);  q2.add(5);
	Queue q3 = q1+q2;
	q3.print();

	return 0; 
} 