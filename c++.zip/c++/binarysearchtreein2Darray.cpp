#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
class Queue
{
public:
    Queue()
    {
        front = rear = 0;
    }
    void enqueue(int data)
    {
        int newrear = rear + 1 % 2000;
        if (newrear == front)
        {
            return;
        }
        theQ[newrear] = data;
        rear = newrear;
    }
    int dequeue()
    {
        if (front == rear)
        {
            return 0;
        }
        int newfront = front + 1 % 2000;
        int returntype = theQ[newfront];
        front = newfront;
        return returntype;
    }
    bool isEmpty()
    {
        if (front == rear)
        {
            return 1;
        }
        return 0;
    }

private:
    int theQ[2000];
    int front;
    int rear;
};

class Tree
{
public:
    Tree()
    {
        root = 0;
        int j, k;
        for (j = 0; j < 20; j++)
            for (k = 0; k < 4; k++)
                node[j][k] = -1;
    }
    int insert(int n)
    {
        int f = root, index = 0;
        while (node[index][0] != -1)
            index++;
        if (index >= 20)
            return -1;
        if (node[root][0] == -1)
        {
            node[root][0] = 1;
            node[root][1] = n;
            return 1;
        }
        else
        {
            node[index][0] = 1;
            node[index][1] = n;
            while (1)
            {
                if (node[f][1] < n)
                {
                    if (node[f][3] == -1)
                    {
                        node[f][3] = index;
                        return 1;
                    }
                    else
                    {
                        f = node[f][3];
                    }
                }
                else
                {
                    if (node[f][2] == -1)
                    {
                        node[f][2] = index;
                        return 1;
                    }
                    else
                    {
                        f = node[f][2];
                    }
                }
            }
        }
    }
    void inorder()//left,root,right
    {
        inorderRec(0);
    }
    void inorderRec(int parent)
    {
        if (parent != -1)
        {
            if (node[parent][2] != -1)
            {
                inorderRec(node[parent][2]);
                cout << ",";
            }
            cout << node[parent][1];
            if (node[parent][3] != -1)
            {
                cout << ",";
                inorderRec(node[parent][3]);
            }
        }
    }
    void preorder()
    {
        preorderRec(0);
    }
    void preorderRec(int parent)//root,left,right
    {
        if (parent != -1)
        {
            cout << node[parent][1];
            if (node[parent][2] != -1)
            {
                cout << ",";
                preorderRec(node[parent][2]);
            }
            if (node[parent][3] != -1)
            {
                cout << ",";
                preorderRec(node[parent][3]);
            }
        }
    }
    void postorder()
    {
        postordreRec(0);
    }
    void postordreRec(int parent)//left,right,root
    {
        if (parent != -1)
        {
            if (node[parent][2] != -1)
            {
                postordreRec(node[parent][2]);
            }
            if (node[parent][3] != -1)
            {
                postordreRec(node[parent][3]);
            }
            if (parent == root)
            {
                cout << node[parent][1];
            }
            else
            {
                cout << node[parent][1] << ",";
            }
        }
    }
    void levelorder()
    {
        Queue newQ;
        int index = 0;
        newQ.enqueue(index);
        cout << node[index][1];
        while (newQ.isEmpty() != 1)
        {
            int parent = newQ.dequeue();
            if (node[parent][2] != -1)//check if there is left child
            {
                cout << "," << node[node[parent][2]][1];//access left child index and print left child
                newQ.enqueue(node[parent][2]);
            }
            if (node[parent][3] != -1)
            {
                cout << "," << node[node[parent][3]][1];
                newQ.enqueue(node[parent][3]);
            }
        }
    }
    void print2darr()
    {
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                cout << node[i][j] << " ";
            }
            cout << endl;
        }
    }

private:
    int node[20][4];
    int root;
};

int main()
{
    Tree *tree = new Tree();
    int j, node;
    srand(time(NULL));
    // for (j = 0; j < 10; j++)
    // {
    //     node = rand() % 10;4
    //     tree->insert(node);
    // }
    tree->insert(55);
    tree->insert(44);
    tree->insert(67);
    tree->insert(23);
    tree->insert(46);
    tree->insert(70);
    tree->insert(100);
    tree->insert(68);
    tree->print2darr();
    tree->inorder();
    printf("\n");
    tree->preorder();
    printf("\n");
    tree->postorder();
    printf("\n");
    tree->levelorder();
    printf("\n");
}