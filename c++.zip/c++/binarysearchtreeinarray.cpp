#include<iostream>
#include<cstdlib>
#include<ctime>

using namespace std;

class Queue
{
public:
    Queue()
    {
        front = rear = 0;
    }
    void enqueue(int data)
    {
        int newrear = rear + 1 % 2000;
        if (newrear == front)
        {
            return;
        }
        theQ[newrear] = data;
        rear = newrear;
    }
    int dequeue()
    {
        if (front == rear)
        {
            return 0;
        }
        int newfront = front + 1 % 2000;
        int returntype = theQ[newfront];
        front = newfront;
        return returntype;
    }
    bool isEmpty()
    {
        if (front == rear)
        {
            return 1;
        }
        return 0;
    }

private:
    int theQ[2000];
    int front;
    int rear;
};
class Tree
{
public:
	Tree()
	{
		int j;
		for(j = 0;j < 2000;j ++)
			root[j] = -1;
	}
	int insert(int node)
	{
		int index = 0;
		while(index < 2000 && root[index] != -1)
		{
			if(root[index] < node)
				index = index * 2 + 2;
			else
				index = index * 2 + 1;
		}
		root[index] = node;

        return index;
	}
	void inorder()
    {
        inordreRec(0);
    }
    void inordreRec(int parent)//left,root,right
    {
        if (root[parent] != -1)
        {
            if (root[parent * 2 + 1] != -1)//left child
            {
                inordreRec(parent * 2 + 1);
                cout << ",";
            }
            cout << root[parent];
            if (root[parent * 2 + 2] != -1)
            {
                cout << ",";
                inordreRec(parent * 2 + 2);
            }
        }
    }
    void preorder()
    {
        preorderRec(0);
    }
    void preorderRec(int parent)//root,left,right
    {
        if (root[parent] != -1)
        {
            cout << root[parent];
            if (root[parent * 2 + 1] != -1)
            {
                cout << ",";
                preorderRec(parent * 2 + 1);
            }
            if (root[parent * 2 + 2] != -1)
            {
                cout << ",";
                preorderRec(parent * 2 + 2);
            }
        }
    }
    void postorder()
    {
        postorderRec(0);
    }
    void postorderRec(int parent)//left,right,root
    {
        if (root[parent] != -1)
        {
            if (root[parent * 2 + 1] != -1)
            {
                postorderRec(parent * 2 + 1);
            }
            if (root[parent * 2 + 2] != -1)
            {
                postorderRec(parent * 2 + 2);
            }
            if (root[parent] == root[0])
            {
                cout << root[parent];
            }
            else
            {
                cout << root[parent] << ",";
            }
        }
    }
    void levelorder()
    {
        Queue newQ;
        int index = 0;
        newQ.enqueue(index);
        cout << root[index];
        while (newQ.isEmpty() != 1)
        {
            int parent = newQ.dequeue();
            if (root[parent * 2 + 1] != -1)
            {
                cout << "," << root[parent * 2 + 1];
                newQ.enqueue(parent * 2 + 1);
            }
            if (root[parent * 2 + 2] != -1)
            {
                cout << "," << root[parent * 2 + 2];
                newQ.enqueue(parent * 2 + 2);
            }
        }
    }

private:
	int root[2000];
};

int main()
{
	Tree *tree = new Tree();
	int j, node;
	srand(time(NULL));
	for(j = 0;j < 10;j ++)
	{
		node = rand();
		tree->insert(node);
	}
	tree->inorder();
	printf("\n");
	tree->preorder();
	printf("\n");
	tree->postorder();
	printf("\n");
	tree->levelorder();
	printf("\n");
}
