#include <iostream>
using namespace std;

int main(){
    int n;
    cin>>n;

    if(n%2 == 0){
        cout<<"even number"<<endl;
    }
    else{
        cout<<"odd number"<<endl;
    }
    return 0;
}