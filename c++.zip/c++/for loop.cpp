#include <iostream>
using namespace std;

int main(){
    // prints Hello C++ for 10 times
for(int i = 0; i < 10; i++)
{
    cout << "Hello C++" << endl;
}
}