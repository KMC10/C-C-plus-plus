#include <iostream>
using namespace std;

void printSum(int d, int e, int f){
    
    cout<<"sum is: "<<d+e+f<<endl;
}

int main (){
    int a = 1;
    int b = 4;
    int c = 3;
    printSum(a,b,c);

}