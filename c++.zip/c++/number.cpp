#include<iostream>
using namespace std;

int main(){
    int first;
    int second;

    cin>>first;
    cin>>second;

    cout<<"sum = "<< first + second <<endl;
    cout<<"difference = "<< second - first <<endl;
    cout<<"product = "<< first * second <<endl;
    cout<<"division = "<< first / second <<endl;
    cout<<"modulus = "<< first % second <<endl;

    return 0;
}

