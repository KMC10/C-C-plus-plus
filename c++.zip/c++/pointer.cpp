#include <iostream>

using namespace std;

int main() {
    int n = 1;
    void *p1;
    int *p2;
    
    p2 = (int*)p1; // typecasting *p2
    p2 = &n; // pointer pointing to the address of a;
    *p2 += 1; // modifying the value stored at the address where p1 is pointing thus changing the value of n

    cout << n << endl; 
    //int a = 1;

/* define a pointer variable, and point it to a using the & operator */
// int * pointer_to_a = &a;

// printf("The value a is %d\n", a);
// printf("The value of a is also %d\n", *pointer_to_a);

  
    return 0;
}