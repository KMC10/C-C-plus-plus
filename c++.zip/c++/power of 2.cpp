#include <iostream>

using namespace std;

int pow_of_2(int x)
{
    if(x<=0)
    {
        cout << "No";
        return 0;
    }
    else if(x == 1)
        {
            cout << "Yes";
            return 0;
        }else if(x%2 == 0)
        {
            pow_of_2(x/2);
        }
        else
            cout << "No";
    
    return 0;
}
int main()
{
    int n;
    cin >> n;

    pow_of_2(n);

}
   
