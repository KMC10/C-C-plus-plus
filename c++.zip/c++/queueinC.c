#include <stdio.h>
#include <string.h>

#define SIZE 100

struct Queue
{
    int data[SIZE];
    int top, bot;
};
//enqueue circular queue
int enqueue(struct Queue *queue, int data)
{
    if (queue->top == (queue->bot + 1) % SIZE) //checking if queue is full
    {
        return -1;

    } //circularly increment bot index by 1
    else {
        queue->data[queue->bot] = data; //add the item at the index that bot is pointing to.
        queue->bot = (queue->bot + 1) % SIZE;
        return 1;
    }
}

int *dequeue(struct Queue *queue)
{
    if (queue->top == queue->bot)//check if queue is empty
    {
        return NULL;
    } else {
        int *data = &queue->data[queue->top];
        queue->top = (queue->top + 1) % SIZE;
        return data;
    }
}

int main()
{
    int data, *temp;
    char command[50];
    struct Queue queue;
    queue.top = 0;
    queue.bot = 0;
    while (1)
    {
        scanf("%s", command);
        if (strcmp(command, "exit") == 0)
        {
            break;
        }
        else if (strcmp(command, "enqueue") == 0)
        {
            printf("Please input a integer data:");
            scanf("%d", &data);
            if (enqueue(&queue, data) == 1)
            {
                printf("Successfully enqueue data into queue.\n");
            }
            else
            {
                printf("Failed to enqueue data into queue.\n");
            }
        }
        else if (strcmp(command, "dequeue") == 0)
        {
            temp = dequeue(&queue);
            if (temp == NULL)
            {
                printf("Failed to dequeue a data from queue.\n");
            }
            else
            {
                printf("Dequeue data %d from queue.\n", *temp);
            }
        }
    }
}