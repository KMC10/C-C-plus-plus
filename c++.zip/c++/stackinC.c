#include <stdio.h>
#include <string.h>
#define SIZE 5

struct Stack
{
    int data[SIZE];  //size is 5
    int top;
};

int push(struct Stack *stack, int data)  //function to push/add data to stack
{
    if (stack->top == SIZE) //check if stack is full
        return -1;
    stack->data[stack->top] = data;   
    stack->top++;
    return 1;
}

int *pop(struct Stack *stack)  
{
    if (stack->top == 0)  //check if stack is empty
        return NULL;
    stack->top--;    //remove data from stack
    return &(stack->data[stack->top]); //return reference of stack
}

int main()
{
    int data, *temp;
    char command[50];
    struct Stack stack;
    stack.top = 0;
    while (1)
    {
        scanf("%s", command);
        if (strcmp(command, "exit") == 0)
        {
            break;
        }
        else if (strcmp(command, "push") == 0)
        {
            printf("Please input a integer data:");
            scanf("%d", &data);
            if (push(&stack, data) == 1)
            {
                printf("Successfully push data %d into stack.\n");
            }
            else
            {
                printf("Failed to push data into stack.\n");
            }
        }
        else if (strcmp(command, "pop") == 0)
        {
            temp = pop(&stack);
            if (temp == NULL)
            {
                printf("Failed to pop a data from stack.\n");
            }
            else
            {
                printf("Pop data %d from stack.\n", *temp);
            }
        }
    }
}