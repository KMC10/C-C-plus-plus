#include <iostream>
#include <string>
using namespace std;

struct Node  //defining a linkedlist node
{
    int data;
    struct Node *next;
};

//creating a linkedlist class
class Linkedlist
{
public:
    //constructor to initialize head and tail to nullptr meaning the list is empty.
    Linkedlist()
    {
        head = nullptr;
        tail = nullptr;

    }
    void createNode(int value)
    {
        Node *temp = new Node;  //creating new memory for the new item;
        temp->data = value;     //set it's data to value;
        temp->next = nullptr;   //set it's next to be nullptr;

        if (head == nullptr)  //check if the linkedlist is empty, if yes then make the head and tail to point to the new item(first item)
        {
            head = temp;
            tail = temp;
        }
        else
        {   
            tail->next = temp;   //if not then make the tail to point at this new item as the last item and set the tail to this new item.
            tail = temp;
        }
    }
    void printList() {
        Node * current = head;

        while (current != nullptr) {
            std::cout << current->value << std::endl;
            current = current->next;
        }
    }


private:
    Node *head;
    Node *tail;
};