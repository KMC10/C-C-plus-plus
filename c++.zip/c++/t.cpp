#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
class Queue
{
public:
    Queue()
    {
        front = rear = 0;
    }
    void enqueue(int data)
    {
        int newrear = rear + 1 % 2000;
        if (newrear == front)
        {
            return;
        }
        theQ[newrear] = data;
        rear = newrear;
    }
    int dequeue()
    {
        if (front == rear)
        {
            return 0;
        }
        int newfront = front + 1 % 2000;
        int returntype = theQ[newfront];
        front = newfront;
        return returntype;
    }
    bool isEmpty()
    {
        if (front == rear)
        {
            return 1;
        }
        return 0;
    }

private:
    int theQ[2000];
    int front;
    int rear;
};

class Tree
{
public:
    Tree()
    {
        root = 0;
        int j, k;
        for (j = 0; j < 20; j++)
            for (k = 0; k < 4; k++)
                node[j][k] = -1;
    }
    int insert(int n)
    {
        int f = root, index = 0;
        while (node[index][0] != -1)
            index++;
        if (index >= 20)
            return -1;
        if (node[root][0] == -1)
        {
            node[root][0] = 1;
            node[root][1] = n;
            return 1;
        }
        else
        {
            node[index][0] = 1;
            node[index][1] = n;
            while (1)
            {
                if (node[f][1] < n)
                {
                    if (node[f][3] == -1)
                    {
                        node[f][3] = index;
                        return 1;
                    }
                    else
                    {
                        f = node[f][3];
                    }
                }
                else
                {
                    if (node[f][2] == -1)
                    {
                        node[f][2] = index;
                        return 1;
                    }
                    else
                    {
                        f = node[f][2];
                    }
                }
            }
        }
    }


int main()
{
    Tree *tree = new Tree();
    int j, node;
    srand(time(NULL));
    // for (j = 0; j < 10; j++)
    // {
    //     node = rand() % 10;
    //     tree->insert(node);
    // }
    tree->insert(55);
    tree->insert(44);
    tree->insert(67);
    tree->insert(23);
    tree->insert(46);
    tree->insert(70);
    tree->insert(100);
    tree->insert(68);
    tree->print2darr();
    tree->inorder();
    printf("\n");
    tree->preorder();
    printf("\n");
    tree->postorder();
    printf("\n");
    tree->levelorder();
    printf("\n");
}