#include <iostream>
using namespace std;

int main() {
    int ages[5];
    float original_price = 50;
    float discount;
    
    float total_price;

    for (int i = 0; i < 5; ++i) {
        cin >> ages[i];
    }
    //your code goes here

    //finding the smallest age
    int min = ages[0];
    for(int j = 1; j < 5; j++){
        if(min > ages[j]){
            min = ages[j];
        }
        
    }
    discount = original_price * min / 100;
    total_price = original_price - discount;
    
    cout << "========" << endl;
    cout << min << endl;
    cout << total_price << endl;
    
    
    
    return 0;
}