#include <iostream>
using namespace std;

//method 1 using a struct
struct Node
{
    int data;
    struct Node *left;
    struct Node *right;
};
//method 2 using a class

class Node
{
public:
    int data;
    struct Node *left;
    struct Node *right;

};