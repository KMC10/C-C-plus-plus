#include <iostream>
#include <string.h>
using namespace std;

// Node
template <class T>
class Node
{
public:
    T data;
    int color;
    Node<T> *left;
    Node<T> *right;
    Node<T> *parent;

    Node() : color(1), left(NULL), right(NULL), parent(NULL) {}
    Node(T data) : data(data), color(1), left(NULL), right(NULL), parent(NULL) {}
    Node(T data, Node<T> *left, Node<T> *right, Node<T> *parent) : data(data), color(1), left(left), right(right), parent(parent) {}
};

// Queue
template <class T>
class Queue
{
private:
    Node<T> *front;
    Node<T> *rear;

public:
    Queue() : front(NULL), rear(NULL) {}

    void Enqueue(T data);
    T Dequeue();
    bool IsEmpty();
};

// Red Black Tree
template <class T>
class Red_Black_Tree
{
private:
    Node<T> *root;
    Node<T> *NIL;

    bool IsNumber(string str);
    int Compare(T a, T b);

    Node<T> *Search(T data);
    Node<T> *Maximum(Node<T> *p);
    void Transplant(Node<T> *u, Node<T> *v);

    void LeftRotate(Node<T> *p);
    void RightRotate(Node<T> *p);

    void InsertFix(Node<T> *p);
    void DeleteFix(Node<T> *p);

public:
    Red_Black_Tree();

    void Insert(T data);
    void Delete(T data);

    string Serialize();
};

// Driver
int main()
{
    string op, data;
    Red_Black_Tree<string> *tree = new Red_Black_Tree<string>();
    while (cin >> op >> data)
    {
        if (op == "insert")
        {
            tree->Insert(data);
        }
        else if (op == "delete")
        {
            tree->Delete(data);
        }
        else
        {
            break;
        }
    }
    cout << tree->Serialize() << endl;
    return 0;
}

// Queue
template <class T>
void Queue<T>::Enqueue(T data)
{
    Node<T> *t = new Node<T>(data);
    if (front == NULL)
    {
        front = t;
        rear = t;
    }
    else
    {
        rear->right = t;
        rear = t;
    }
}

template <class T>
T Queue<T>::Dequeue()
{
    Node<T> *p = front;
    T x = NULL;
    if (front)
    {
        front = front->right;
        x = p->data;
        delete p;
    }
    return x;
}

template <class T>
bool Queue<T>::IsEmpty()
{
    return front == NULL;
}

// Red Black Tree : Public
template <class T>
Red_Black_Tree<T>::Red_Black_Tree()
{
    NIL = new Node<T>();
    NIL->color = 0;
    root = NIL;
}

template <class T>
void Red_Black_Tree<T>::Insert(T data)
{
    Node<T> *p = root, *q = NULL, *t = NULL;
    while (p != NIL)
    {
        q = p;
        if (Compare(data, p->data) < 0)
        {
            p = p->left;
        }
        else if (Compare(data, p->data) > 0)
        {
            p = p->right;
        }
        else
            return;
    }
    t = new Node<T>(data, NIL, NIL, q);
    if (q == NULL)
    {
        root = t;
    }
    else if (Compare(t->data, q->data) < 0)
    {
        q->left = t;
    }
    else
    {
        q->right = t;
    }
    InsertFix(t);
}

template <class T>
void Red_Black_Tree<T>::Delete(T data)
{
    Node<T> *z = Search(data);
    if (z == NIL)
    {
        return;
    }
    Node<T> *x = NULL, *y = z;
    int y_original_color = y->color;
    if (z->left == NIL)
    {
        x = z->right;
        Transplant(z, z->right);
    }
    else if (z->right == NIL)
    {
        x = z->left;
        Transplant(z, z->left);
    }
    else
    {
        y = Maximum(z->left);
        y_original_color = y->color;
        x = y->left;
        if (y->parent == z)
        {
            x->parent = y;
        }
        else
        {
            Transplant(y, y->left);
            y->left = z->left;
            y->left->parent = y;
        }
        Transplant(z, y);
        y->right = z->right;
        y->right->parent = y;
        y->color = z->color;
    }
    if (y_original_color == 0)
    {
        DeleteFix(x);
    }
}

template <class T>
string Red_Black_Tree<T>::Serialize()
{
    string tree = "";
    Queue<Node<T> *> q;
    q.Enqueue(root);
    while (!q.IsEmpty())
    {
        Node<T> *p = q.Dequeue();
        if (p != NIL)
        {
            tree += p->data + ",";
            q.Enqueue(p->left);
            q.Enqueue(p->right);
        }
        else
        {
            tree += "NULL,";
        }
    }
    for (int i = tree.length() - 1; i >= 0; i--)
    {
        if (tree[i] == ',')
        {
            tree.erase(i, 1);
        }
        else if (tree[i] == 'L' && tree[i - 1] == 'L' && tree[i - 2] == 'U' && tree[i - 3] == 'N')
        {
            tree.erase(i - 3, 4);
            i -= 3;
        }
        else
        {
            break;
        }
    }
    return tree;
}

// Red Black Tree : Private
template <class T>
bool Red_Black_Tree<T>::IsNumber(string str)
{
    for (int i = 0; i < str.length(); i++)
    {
        if (str[i] < '0' || str[i] > '9')
        {
            return false;
        }
    }
    return true;
}

template <class T>
int Red_Black_Tree<T>::Compare(T a, T b)
{
    if (IsNumber(a) || IsNumber(b))
    {
        if (IsNumber(a) && IsNumber(b))
        {
            int num1 = stoi(a);
            int num2 = stoi(b);
            if (num1 < num2)
            {
                return -1;
            }
            else if (num1 > num2)
            {
                return 1;
            }
        }
        return 0;
    }
    else
    {
        return strcmp(a.c_str(), b.c_str());
    }
}

template <class T>
Node<T> *Red_Black_Tree<T>::Search(T data)
{
    Node<T> *p = root;
    while (p != NIL && Compare(data, p->data))
    {
        if (Compare(data, p->data) < 0)
        {
            p = p->left;
        }
        else
        {
            p = p->right;
        }
    }
    return p;
}

template <class T>
Node<T> *Red_Black_Tree<T>::Maximum(Node<T> *p)
{
    while (p->right != NIL)
    {
        p = p->right;
    }
    return p;
}

template <class T>
void Red_Black_Tree<T>::Transplant(Node<T> *u, Node<T> *v)
{
    if (u->parent == NULL)
    {
        root = v;
    }
    else if (u == u->parent->left)
    {
        u->parent->left = v;
    }
    else
    {
        u->parent->right = v;
    }
    v->parent = u->parent;
}

template <class T>
void Red_Black_Tree<T>::LeftRotate(Node<T> *p)
{
    Node<T> *pr = p->right;
    p->right = pr->left;
    if (p->right != NIL)
    {
        p->right->parent = p;
    }
    pr->parent = p->parent;
    if (pr->parent == NULL)
    {
        root = pr;
    }
    else if (p == p->parent->left)
    {
        p->parent->left = pr;
    }
    else
    {
        p->parent->right = pr;
    }
    pr->left = p;
    p->parent = pr;
}

template <class T>
void Red_Black_Tree<T>::RightRotate(Node<T> *p)
{
    Node<T> *pl = p->left;
    p->left = pl->right;
    if (p->left != NIL)
    {
        p->left->parent = p;
    }
    pl->parent = p->parent;
    if (pl->parent == NULL)
    {
        root = pl;
    }
    else if (p == p->parent->left)
    {
        p->parent->left = pl;
    }
    else
    {
        p->parent->right = pl;
    }
    pl->right = p;
    p->parent = pl;
}

template <class T>
void Red_Black_Tree<T>::InsertFix(Node<T> *p)
{
    Node<T> *grandparent = NULL, *parent = NULL, *uncle = NULL;
    while (p != root && p->color == 1 && p->parent->color == 1)
    {
        parent = p->parent;
        grandparent = p->parent->parent;
        if (parent == grandparent->left)
        {
            uncle = grandparent->right;
            if (uncle != NIL && uncle->color == 1)
            {
                grandparent->color = 1;
                parent->color = 0;
                uncle->color = 0;
                p = grandparent;
            }
            else
            {
                if (p == parent->right)
                {
                    LeftRotate(parent);
                    p = parent;
                    parent = p->parent;
                }
                RightRotate(grandparent);
                parent->color = 0;
                grandparent->color = 1;
                p = parent;
            }
        }
        else
        {
            uncle = grandparent->left;
            if (uncle != NIL && uncle->color == 1)
            {
                grandparent->color = 1;
                parent->color = 0;
                uncle->color = 0;
                p = grandparent;
            }
            else
            {
                if (p == parent->left)
                {
                    RightRotate(parent);
                    p = parent;
                    parent = p->parent;
                }
                LeftRotate(grandparent);
                parent->color = 0;
                grandparent->color = 1;
                p = parent;
            }
        }
    }
    root->color = 0;
}

template <class T>
void Red_Black_Tree<T>::DeleteFix(Node<T> *p)
{
    Node<T> *sibling = NULL;
    while (p != root && p->color == 0)
    {
        if (p == p->parent->left)
        {
            sibling = p->parent->right;
            if (sibling->color == 1)
            {
                sibling->color = 0;
                p->parent->color = 1;
                LeftRotate(p->parent);
                sibling = p->parent->right;
            }
            if (sibling->left->color == 0 && sibling->right->color == 0)
            {
                sibling->color = 1;
                p = p->parent;
            }
            else
            {
                if (sibling->right->color == 0)
                {
                    sibling->left->color = 0;
                    sibling->color = 1;
                    RightRotate(sibling);
                    sibling = p->parent->right;
                }
                sibling->color = p->parent->color;
                p->parent->color = 0;
                sibling->right->color = 0;
                LeftRotate(p->parent);
                p = root;
            }
        }
        else
        {
            sibling = p->parent->left;
            if (sibling->color == 1)
            {
                sibling->color = 0;
                p->parent->color = 1;
                RightRotate(p->parent);
                sibling = p->parent->left;
            }
            if (sibling->right->color == 0 && sibling->left->color == 0)
            {
                sibling->color = 1;
                p = p->parent;
            }
            else
            {
                if (sibling->left->color == 0)
                {
                    sibling->right->color = 0;
                    sibling->color = 1;
                    LeftRotate(sibling);
                    sibling = p->parent->left;
                }
                sibling->color = p->parent->color;
                p->parent->color = 0;
                sibling->left->color = 0;
                RightRotate(p->parent);
                p = root;
            }
        }
    }
    p->color = 0;
}