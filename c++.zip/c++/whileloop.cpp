#include <iostream>
using namespace std;

int main(){
    int n = 0;
    int target = 20;
    while(n<target){
        n++;
        cout<<n<<endl;
        if(n==target){
            break;
        }
        
       // return 0;
    }
}