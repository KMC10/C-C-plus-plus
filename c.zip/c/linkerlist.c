#include <stdio.h>
#include <stdlib.h>

struct Node {
  struct Node *next, *prev;
  int data;
};
struct Node *insertFromHead(struct Node **, int );
struct Node *insertFromTail(struct Node **, int );
struct Node *insertAfter(struct Node *, int, struct Node *);
struct Node *removeFromHead(struct Node **);
struct Node *removeFromTail(struct Node **);
struct Node *removeElement(struct Node **, struct Node *);

struct Node *push(struct Node **, int );
struct Node *pop(struct Node **);

struct Node *find(struct Node *, int );
struct Node *exist(struct Node *, struct Node *);
void display(struct Node *head);

int main() {
  struct Node *stack = NULL, *k;
  int j;
  for(j = 0;j < 10;j ++) {
    push(&stack, j);
  }
  k = pop(&stack);
  while(k) {
    printf("%d ", k->data);
    k = pop(&stack);
  }
  return 0;
}

struct Node *insertFromHead(struct Node **head, int d) {
  struct Node *newNode = malloc(sizeof(struct Node));
  if(newNode == NULL)
    return NULL;
  newNode->data = d;
  newNode->prev = NULL;
  newNode->next = NULL;
  if(*head == NULL) {
    *head = newNode;
    return newNode;
  }
  else {
    (*head)->prev = newNode;
    newNode->next = (*head);
    (*head) = newNode;
    return newNode;
  }
}

struct Node *insertFromTail(struct Node **head, int d) {
  struct Node *newNode = malloc(sizeof(struct Node));
  if(newNode == NULL)
    return NULL;
  newNode->data = d;
  newNode->prev = NULL;
  newNode->next = NULL;
  if(*head == NULL) {
    *head = newNode;
    return newNode;
  }
  else {
    struct Node *tail = *head;
    while(tail->next != NULL)
      tail = tail->next;
    tail->next = newNode;
    newNode->prev = tail;
    return newNode;
  }
}

struct Node *insertAfter(struct Node *head, int d, struct Node *at) {
  if(exist(head, at) != NULL) {
    struct Node *newNode = malloc(sizeof(struct Node));
    if(newNode == NULL)
      return NULL;
    newNode->data = d;
    newNode->prev = NULL;
    newNode->next = at->next;
    if(at->next != NULL)
      at->next->prev = newNode;
    at->next = newNode;
    newNode->prev = at;
    return newNode;
  }
  else {
    return NULL;
  }
}

struct Node *removeFromHead(struct Node **head) {
  if(*head == NULL)
    return NULL;
  struct Node *temp = *head;
  *head = (*head)->next;
  if(*head != NULL)
    (*head)->prev = NULL;
  temp->next = NULL;
  return temp;
}

struct Node *removeFromTail(struct Node **head) {
  if(*head == NULL)
    return NULL;
  struct Node *temp = *head;
  while(temp->next != NULL)
    temp = temp->next;
  if(temp == *head) {
    *head = NULL;
    return temp;
  }
  else {
    temp->prev->next = NULL;
    temp->prev = NULL;
    return temp;
  }
}

struct Node *removeElement(struct Node **head, struct Node *n) {
  if(exist(*head, n) == NULL)
    return NULL;
  if(n == *head) {
    return removeFromHead(head);
  }
  else {
    struct Node *prev = n->prev;
    struct Node *next = n->next;
    prev->next = next;
    if(next != NULL)
      next->prev = prev;
    n->prev = NULL;
    n->next = NULL;
    return n;
  }
}

struct Node *find(struct Node *head, int d) {
  while(head != NULL) {
    if(head->data == d)
      return head;
    head = head->next;
  }
  return NULL;
}

struct Node *exist(struct Node *head, struct Node *n) {
  while(head != NULL) {
    if(head == n)
      return n;
    head = head->next;
  }
  return NULL;
}

void display(struct Node *head) {
  struct Node *cur = head, *tail = NULL;
  while(cur != NULL) {
    printf("%d ", cur->data);
    tail = cur;
    cur = cur->next;
  }
  printf("\n");
  cur = tail;
  while(cur != NULL) {
    printf("%d ", cur->data);
    cur = cur->prev;
  }
  printf("\n");
}

struct Node *push(struct Node **head, int d) {
  return insertFromHead(head, d);
}
struct Node *pop(struct Node **head) {
  return removeFromHead(head);
}