#include <stdio.h>
#include <stdlib.h>
#define MAXSIZE 100

struct Stack {
  int data[MAXSIZE];
  int index;
};

int *push(struct Stack *s, int d) {
  if(s->index == MAXSIZE - 1)
    return NULL;
  s->data[s->index] = d;
  s->index ++;
  return &(s->data[s->index - 1]);
}

int *pop(struct Stack *s) {
  if(s->index == 0)
    return NULL;
  s->index --;
  return &(s->data[s->index]);
}

int main() {
  struct Stack *s = malloc(sizeof(struct Stack));
  int j;
  for(j = 0;j < 10;j ++) {
    push(s, j);
  }

  int *p = pop(s);
  while(p != NULL) {
    printf("%d ", *p);
    p = pop(s);
  }
  return 0;
}