#include <stdio.h>
#include <stdlib.h>


struct TreeNode {
    int data;
    struct Node *children;
};

struct Node {
  struct Node *next, *prev;
  struct TreeNode *data;
};


struct Node *insertFromHead(struct Node **, struct TreeNode *);
struct Node *insertFromTail(struct Node **, struct TreeNode *);

struct TreeNode *insertToTree(struct TreeNode **, struct TreeNode *, int d);

void preOrder(struct TreeNode *root);
void preOrderR(struct TreeNode *root);
void postOrder(struct TreeNode *root);
void postOrderR(struct TreeNode *root);
void levelOrder(struct TreeNode *root);

int depth(struct TreeNode *root, struct TreeNode *node);
int height(struct TreeNode *root);

int main() {
  struct TreeNode *root = NULL;
  insertToTree(&root, NULL, 1);
  struct TreeNode *node2 = insertToTree(&root, root, 2);
  //printf("%d", node2->data);
  struct TreeNode *node3 = insertToTree(&root, root, 3);
  insertToTree(&root, node2, 4);
  struct TreeNode *node5 = insertToTree(&root, node2, 5);
  insertToTree(&root, node2, 6);
  insertToTree(&root, node3, 7);
  insertToTree(&root, node3, 8);
  insertToTree(&root, node5, 9);
  insertToTree(&root, node5, 10);
  insertToTree(&root, node5, 11);
  struct TreeNode *node12 = insertToTree(&root, node5, 12);
  preOrderR(root);
  printf("\n");
  preOrder(root);
  printf("\n");
  postOrderR(root);
  printf("\n");
  postOrder(root);
  printf("\n");
  printf("%d %d %d %d\n", depth(root, node2), depth(root, node3), depth(root, node5), depth(root, node12));
  printf("%d\n", height(root));
  printf("%d %d %d %d\n", height(node2), height(node3), height(node5), height(node12));
  return 0;
}

struct Node *insertFromHead(struct Node **head, struct TreeNode *d) {
  struct Node *newNode = malloc(sizeof(struct Node));
  if(newNode == NULL)
    return NULL;
  newNode->data = d;
  newNode->prev = NULL;
  newNode->next = NULL;
  if(*head == NULL) {
    *head = newNode;
    return newNode;
  }
  else {
    (*head)->prev = newNode;
    newNode->next = (*head);
    (*head) = newNode;
    return newNode;
  }
}
struct Node *insertFromTail(struct Node **head, struct TreeNode *d) {
  struct Node *newNode = malloc(sizeof(struct Node));
  if(newNode == NULL)
    return NULL;
  newNode->data = d;
  newNode->prev = NULL;
  newNode->next = NULL;
  if(*head == NULL) {
    *head = newNode;
    return newNode;
  }
  else {
    struct Node *tail = *head;
    while(tail->next != NULL)
      tail = tail->next;
    tail->next = newNode;
    newNode->prev = tail;
    return newNode;
  }
}
struct TreeNode *insertToTree(struct TreeNode **root, struct TreeNode *parent, int d) {
    struct TreeNode *newNode = malloc(sizeof(struct TreeNode));
    newNode->data = d;
    newNode->children = NULL;
    if(*root == NULL) {
        *root = newNode;
        return newNode;
    }
    return insertFromTail(&(parent->children), newNode)->data;
};

void preOrder(struct TreeNode *root) {
    struct TreeNode *stack[1000] = {};
    int index = 0;
    stack[index] = root;
    index ++;
    while(index > 0) {
        index --;
        printf("%d ", stack[index]->data);
        struct TreeNode *temp = stack[index];
        struct Node *cur = temp->children;
        while(cur != NULL && cur->next != NULL)
            cur = cur->next;
        while(cur != NULL) {
            stack[index] = cur->data;
            index ++;
            cur = cur->prev;
        }
    }
}

void preOrderR(struct TreeNode *root) {
    if(root == NULL)
        return;
    printf("%d ", root->data);
    struct Node *cur = root->children;
    while(cur != NULL) {
        preOrderR(cur->data);
        cur = cur->next;
    }
}

void postOrder(struct TreeNode *root) {
    struct TreeNode *stack[1000] = {};
    struct TreeNode *stack2[1000] = {};
    int index = 0, index2 = 0;
    stack[index] = root;
    index ++;
    while(index > 0) {
        index --;
        stack2[index2] = stack[index];
        index2 ++;
        struct TreeNode *temp = stack[index];
        struct Node *cur = temp->children;
        //while(cur != NULL && cur->next != NULL)
        //    cur = cur->next;
        while(cur != NULL) {
            stack[index] = cur->data;
            index ++;
            cur = cur->next;
        }
    }
    while(index2 > 0) {
        index2 --;
        printf("%d ", stack2[index2]->data);
    }
}

void postOrderR(struct TreeNode *root) {
    if(root == NULL)
        return;
    struct Node *cur = root->children;
    while(cur != NULL) {
        postOrderR(cur->data);
        cur = cur->next;
    }
    printf("%d ", root->data);
}

void levelOrder(struct TreeNode *root) {
    struct TreeNode *queue[1000];
    int index = 0, front = 0;
    queue[index] = root;
    index ++;
    while(front < index) {
        printf("%d ", queue[front]->data);
        struct Node *cur = queue[front]->children;
        while(cur != NULL) {
            queue[index] = cur->data;
            index ++;
            cur = cur->next;
        }
        front ++;
    }
}

int depth_(struct TreeNode *r, struct TreeNode *node, int d) {
    if(node == r)
        return d;
    struct Node *cur = r->children;
    while(cur != NULL) {
        int temp = depth_(cur->data, node, d + 1);
        if(temp != -1)
            return temp;
        cur = cur->next;
    }
    return -1;
}

int depth(struct TreeNode *root, struct TreeNode *node) {
    return depth_(root, node, 0);
}
int height_(struct TreeNode *root, int h) {
    if(root == NULL)
        return h - 1;
    //printf("%d:%d\n", root->data, h);
    struct Node *cur = root->children;
    int max = h;
    while(cur != NULL) {
        int temp = height_(cur->data, h + 1);
        if(temp > max)
            max = temp;
        cur = cur->next;
    }
    return max;
}

int height(struct TreeNode *root) {
    return height_(root, 0);
}