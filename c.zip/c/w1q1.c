#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    float b;
    char c;

    scanf("%d%f %c",&a,&b,&c);
    printf("%d\n%f\n%c\n",a,b,c);
    return 0;

}