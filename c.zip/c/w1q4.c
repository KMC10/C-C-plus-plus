#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    float avg = (a+b+c)/3;
    printf("%f",avg);
    return 0;

} 